# Biswise Operators

# Bitwise And = &
# Bitwise or  = |
# Bitwise Not = ~
# Bitwise Xor = ^
# Bitwise Right Shift = >>
# Bitwise Left Shift = <<
