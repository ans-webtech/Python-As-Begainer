# What is Operator?
# Operators are special symbols which perform
# different computations in python.

# Types of Operators
# 1. Arithmetic
# 2. Comparison or Relational
# 3. Logical
# 4. Bitwise
# 5. Assignment
# 6. Identity
# 7. Membership

# Example of Arithmetic Operators
a, b = 25, 10
print(a+b)          # 35
print(a-b)          # 15
print(a*b)          # 250
print(a/b)          # 2.5
print(a//b)         # 2
print(a%b)          # 5
print(3**2)         # 9

