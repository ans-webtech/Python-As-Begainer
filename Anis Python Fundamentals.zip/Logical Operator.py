#   Example of Logical Operators
'''
name = "Md. Anis"
age = 31

name_matched = name == "Md. Anis"
age_matched = age > 25

print(name_matched)
print(age_matched)
'''


#   and logical operator
#   if both value is true it returns true, both value false then it returns false
#   in on of the value is false then it returns false.
name = "Kamal"
age = 6
name_matched = name == "Kamal"
age_matched = age == 6
#   print(name_matched and age_matched)
print(name_matched and age_matched)

# or operator is opposite to and operator
#   print(name_matched or age_matched)
print(name_matched or age_matched)

#   Not Operator
#   print(not name_matched)
#   print(not age_matched)


#   Truth Table
#   Condition_A    Condition_B      and     or
#   True            True            True    Ture
#   True            False           False   True
#   False           False           False   True
#   False           False           False   False
