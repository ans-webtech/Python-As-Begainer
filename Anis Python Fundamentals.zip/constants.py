PI = 3.1416
Weak_Day = 8
DAY_OF_YEAR = 365