# Control Structure or Decision Maker Structure
# Control Structure 1: Conditions
# Control Structure 2: Loops
a, b = 10, 20
c = a + b
d = a - b
result = c*c + d*d
print(result)

# Conditions
'''
IF
ELIF
ELSE
'''

# Loop
'''
For Loop
While Loop
'''
