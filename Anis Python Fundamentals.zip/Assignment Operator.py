n = 10

'''
n += 5      # n = n+5
n -= 5      # n = n-5
n *= 5      # n = n*5
n /= 5      # n = n/5
n %= 5      # n = n%5
n **=5      # n = n**5
n//= 5      # n = n//5

'''
n = 5
print(n)