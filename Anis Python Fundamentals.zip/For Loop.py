# specified Range, List User Email, Set, Map, Data Structure
# Need Sequence: String, List, Set, Map
'''

# how to write 1 to 9 vertically
for i in range(10):
    print(i)
'''

# How to write 0 to 100 with 5 step gap

r = range(0, 100, 5)
print(list(r))

# How to write Form 100 to 1 with 5 step gap
r = range(100, 0, -5)    # - 5 is required to reduce the value
print(list(r))