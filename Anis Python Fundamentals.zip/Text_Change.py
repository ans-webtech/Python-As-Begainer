txt = "I love apples, apple are my love favorite fruit love , Love, New, Love , love"
x = txt.count("apple")
print(x)

txt = "I love email, gmail, apples, apple are my love favorite your mailfruit love , Love, sendemailNew, Love , love"
x = txt.count("mail")
print(x)