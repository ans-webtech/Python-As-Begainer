print("hello world")
# I have started to learn python
a = 10
b = 5
c = (a+b)
d = (a-b)
m = (a*b)
n = (a/b)
# I can easily use python as a calculator
print(c)
print(d)
print(m)
print(n)
