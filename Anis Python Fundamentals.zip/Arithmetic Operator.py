# Example of Arithmetic Operators
a, b = 25, 10
print(a+b)          # 35
print(a-b)          # 15
print(a*b)          # 250
print(a/b)          # 2.5
print(a//b)         # 2
print(a%b)          # 5
print(3**2)         # 9