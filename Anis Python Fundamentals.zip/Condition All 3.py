# If
'''
bakul = 25
mukul = 25
'''
'''
# print(bakul > mukul)
if bakul > mukul:
    print("bakul is Older Than mukul")
if mukul < bakul:
    print("mukul is younger than bakul")
'''
'''
if bakul > mukul:
    print("bakul is Older Than mukul")
if mukul < bakul:
    print("mukul is younger than bakul")
'''

# ELSE
a, b = 10, 20
if a > b:
    print("A is Greater")
elif b > a:
    print("B is Greater")
else:
    print("Both Are Same")
