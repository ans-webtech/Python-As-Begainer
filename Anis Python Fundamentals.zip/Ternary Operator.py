# Normal Code
'''
# Print Min Value
a, b = 10000, 100
if a<b:
    min = a
else:
    min = b
print(min)

# Print Max Value
a, b = 10, 500
if a>b:
    max = a
else:
    max = b
print(max)
'''

# Short circuit Evaluation   1
a, b = 10, 100
min = a if a<b else b
print(min)

# Short circuit Evaluation   2
name = "Md. Anisur Rahman"
default_name = name if name != "" else "Guest"
print(default_name)