# Break Statement
'''
# Break Statement
for i in range(1, 10):
    if i == 5: break
    print(i)
'''
# Continue Statement
for i in range(1, 20):
    if i == 10: continue
    print(i)