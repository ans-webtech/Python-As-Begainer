while True:
    for i in range(11):
        for j in range(i + 2):
            print(j, end="\t")
        print(i)


    for i in range(21):
        for j in range(i + 2):
            print(j, end="\t")
        print(i)

    for i in range(31):
        for j in range(i + 2):
            print(j, end="\t")
        print(i)
    for i in range(41):
        for j in range(i + 2):
            print(j, end="\t")
        print(i)
    for i in range(51):
        for j in range(i + 2):
            print(j, end="\t")
        print(i)