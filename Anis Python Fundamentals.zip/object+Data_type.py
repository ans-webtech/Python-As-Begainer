# In Python, everything is an object

# Major Data Type in Python
name = 'Md. Anis'
n = 1
m = 1.0
c = 1 + 5j
b = True

# See the Outcome
print(type(name))
print(type(n))
print(type(m))
print(type(c))
print(type(b))

# Advanced Data Types in python
li = [1, 1, 2, 3]
s = {1, 1, 2, 2}
t = (1, 2, 3)
d = {'name': 'Md. Anis', 'chanel': 'Ans WebTech'}

# See the Outcome
print(type(li))
print(type(s))
print(type(t))
print(type(d))


