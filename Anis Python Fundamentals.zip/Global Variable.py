# Python Global Variable

x = "Awesome"
def myfunc():
    print("Python Is " + x)
myfunc()