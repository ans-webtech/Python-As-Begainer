# Identity Operator
n = 10
m = 10
o = 20
'''
print(n is m)
print(n is o)
print(o is not m)

li1 = [1, 2, 3]
li2 = [1, 2, 3]
print(li1 == li2)
print(li1 is li2)
print(li1 is not li2)
'''

# Membership Operator
name = 'HM Nayem'
print('H' in name)
print('k' not in name)