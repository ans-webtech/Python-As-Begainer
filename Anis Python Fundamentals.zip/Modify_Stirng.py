a = "my home is in barishal"
print(a.upper())

b = "I LIVE IN DHAKA"
print(b.lower())

a = " Hello, World"
print(a.strip()) # returns "Hello, World!"

a = "Hello, H!"
print(a.replace("H", "J"))

a = "Sima, Sanu, Sikor, Sawon, sunu, sundor"
print(a.replace("S", "R"))
