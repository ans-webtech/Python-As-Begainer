import datetime
current_datetime = datetime.datetime.now()
date_string = current_datetime.strftime("%y-%m-%d")
time_string = current_datetime.strftime("%H:%M:%S")
print("Date: ", date_string)
print("Time: ", time_string)
