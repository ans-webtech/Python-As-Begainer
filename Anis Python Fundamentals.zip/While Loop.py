'''
# Loop Start
while True:
    print("The Name Of Our Country is Bangaldesh")

# Loop Stop
loop = True
while loop:
    print('Stack Learner')
    loop = False

while True:
    a = int(input("A = "))
    b = int(input("B = "))
    print("Result = " + str(a+b))



res = 'y'
while res == 'y':
    a = int(input("A = "))
    b = int(input("B = "))
    print("Result = " + str(a+b))
    res = input("Do you want to continue? (y/n) ")












