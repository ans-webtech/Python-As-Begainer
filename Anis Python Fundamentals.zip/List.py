# Python List
# Change the second value with two new value

thislist = ["apple", "banan", "cherry"]
thislist[1:2] = ["blackcurrent, watermelon"]
print(thislist)
# Change the 3rd value in list
thislist = ["apple", "banan", "cherry"]
thislist[2] = "Watermelon"
print(thislist)

thislist = ["a", "b", "c", "d", "e"]
thislist.insert(4, "k")
print(thislist)

THISlIST = ["m", "n", "o"]
THISlIST[2] = "z"
print(THISlIST)