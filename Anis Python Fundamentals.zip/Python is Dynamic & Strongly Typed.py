n = 10
print('Test' + str(n))