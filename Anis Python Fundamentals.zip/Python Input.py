name = input("Enter Your Name: ")
company = input("Enter Company name: ")
