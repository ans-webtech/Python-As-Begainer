'''
for i in range(10):
    for i in range(5):
        print(i, end=' ')
    print('')

# with i value

for i in range(5):
    for j in range(5):
        print(i, end='')
    print('')

# with j value
for i in range(10):
    for j in range(100+1):
        print(j, end='\t')
    print('')

for i in range(20):
    for j in range(i+2):
        print(j, end='\t')
    print('')

'''

