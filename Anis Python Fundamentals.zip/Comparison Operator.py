# Example of Comparison Operators
a, b = 20, 10
print(a > b)    # True
print(a < b)    # False
print(a == b)   # False
print(a != b)   # True [This is called NOT Operator]

c, d = 30, 30
print(c >= d)   # True
print(c <= d)   # True
print(c == d)   # True