'''
# nested loop

age = int(input("What is Your Age? "))
if age >= 18:
    nationality = input("Do You Have Your NID Card? (y/n) ")
    if nationality == "y":
        tradelicense = input("Do You Have Trade License? (y/n) ")
        if tradelicense == 'y':
            cow = input("Do you have a cow? (y/n) ")
            if cow == "y":
                your_class = int(input("Enter your class no: "))
                if your_class <= 10:
                    print("You can apply for basic ")
                else:
                    print("MS word")
            else:
                print("you need a cow for treatment")
        else:
            print('You are not Eligible')
    else:
        print('You Must Have Your NID Card')
else:
    print("You are too young")

    if something2:
        if something3:
            if something3:
                if something4:
                    pass
'''
age = int(input("What is Your Age? "))
if age >= 18:
    nationality = input("Do You Have Your NID Card? (y/n) ")
    if nationality == "y":
        tradelicense = input("Do You Have Trade License? (y/n) ")
        if tradelicense == 'y':
            print('Congratulation, Wait For A Moment')
        else:
            print('You are not Eligible')
    else:
        print('You Must Have Your NID Card')
else:
    print("You are too young")